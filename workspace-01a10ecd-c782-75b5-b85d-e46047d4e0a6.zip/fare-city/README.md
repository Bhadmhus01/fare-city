# FARE CITY — one bus, every city

A browser game about the informal transit hustle. You start as a Lagos danfo
driver: load passengers in the yellow box, drop them where they asked, shout
**OWA!** with the horn, dodge potholes, obey LASTMA. Then you earn stars, unlock
Accra, Nairobi, Cairo, Cape Town, Mumbai, Jakarta, Bangkok, London and New York —
each one a real city with its own vehicle, streets, currency, slang, radio
station, weather and traffic.

Everything is a single self-contained `index.html` (~170 KB, no dependencies, no
build step required to play, works offline and installs like an app).

```
fare-city/
├── index.html            ← the game. Open it. That is the whole thing.
├── parts/                ← the source it was stitched from
│   ├── 00-head.html      CSS + design tokens
│   ├── 01-body.html      all screens (boot, HUD, home, map, city, garage, board, result, settings, pause)
│   ├── 02-cities.js      the 10 city packs (pure data — this is the growth lever)
│   ├── 03-i18n.js        English + Nigerian Pidgin string tables
│   ├── 04-core.js        save file, economy, progression, leaderboard, share
│   ├── 05-audio.js       synthesised engine, horn, SFX and a per-city radio sequencer
│   ├── 06-render.js      canvas renderer (pseudo-3D road, traffic, skyline, bridges, weather)
│   ├── 07-game.js        physics, passengers, combos, checkpoints, scoring
│   └── 08-ui.js          screens, input, loop, PWA install
├── build.sh              ./build.sh  →  stitches parts/ into index.html
├── sw.js                 service worker (offline cache)
├── manifest.webmanifest  installable app metadata
├── icon.svg              app icon
├── ADD-A-CITY.md         paste-ready template + checklist for a new city
└── world-tour.png        contact sheet: the same engine driving 10 cities
```

Rebuild after editing any part:

```bash
cd fare-city && ./build.sh
```

---

## How to play

| Thing | How |
|---|---|
| Steer | drag anywhere, or ← → |
| Gas / Brake | the two pedals, or ↑ ↓ |
| Horn (OWA!) | 📢 or `H` |
| Hop | ⤴ or `Space` — clears potholes, bumps and cones |
| Overtake boost | ⚡ or `Shift` |
| Pause / radio / mute | `P` · `R` · `M` |

**Auto-pedal is on by default**, so on a phone one thumb is enough: you steer,
the bus drives. Turn it off in Settings if you want to do everything yourself.

Scoring rules that matter:

* **Yellow box** = bus stop. Stop *inside* it, under 46 km/h, and passengers board.
* **Drop passengers at their stop** and they pay full fare plus a tip. Miss their
  stop and they get off at the next one anyway, pay half, and your combo resets.
* **Horn near people** (okada, boda, tuk-tuk, pedestrians, hawkers) scatters them
  and builds a combo up to **x4**. Every OWA! is credits.
* **Pink box** = checkpoint (LASTMA, police, wardens). Crawl through under
  90 km/h and you get waved on and paid a small courtesy bonus; blast past and
  you pay a fine.
* **Clean run** (no fines, no crashes, no missed stops) adds 15% at the end.

Each route has three star targets in **fare index** — a currency-neutral score,
which is how Lagos, London and New York end up on the same leaderboard.

---

## What each city carries (the scaling point)

Every city is one data block. Nothing in the engine knows the word "Lagos".

| | Lagos | Accra | Nairobi | Cairo | Cape Town | Mumbai | Jakarta | Bangkok | London | New York |
|---|---|---|---|---|---|---|---|---|---|---|
| Vehicle | Danfo | Trotro | Matatu | Microbus | Minibus taxi | BEST bus | Angkot | City bus | Routemaster | MTA bus |
| Currency | ₦ | GH₵ | KSh | E£ | R | ₹ | Rp | ฿ | £ | $ |
| Horn call | OWA! | Ta! Ta! | Beep! Beep! | Beep beep! | Tu! Tu! | Pom! Pom! | Tiiin! | Peep! Peep! | Beep! | HONK! |
| Station | Wazobia FM | Joy FM | Ghetto Radio | Nile FM | Good Hope FM | Radio Mirchi | Prambors | Cool Fahrenheit | Time Out Radio | Hot 97 |
| Genre | Afrobeats | Highlife | Gengetone | Mahraganat | Amapiano | Bollywood | Dangdut | Mor lam | UK garage | Hip hop |
| Lanes | 3 | 3 | 4 | 4 | 3 | 4 | 4 | 4 | 4 | 4 |
| Weather | haze | – | – | dust | – | rain | haze | rain | rain | – |
| Hazard flavour | LASTMA | police barrier | traffic police | police post | metro police | constable, sacred cow | polisi, floods | tourist police, floods | cameras, cones | NYPD, cones |

Adding an eleventh city is one file edit and one screenshot check — see
`ADD-A-CITY.md`. The engine has no per-city branches except for which road
props to place and which of three scenery kinds (city / bridge / coast) a route
uses.

---

## Global-ready, honestly

What is real today:

* **Currency is local everywhere.** A credit is the base unit; each city declares
  `fx` (local units per credit). Fares, parts, fines, tips and the wallet all
  render in the currency of wherever you are standing. The **fare index** is the
  currency-neutral number used for stars and the global board, so a Cairo run and
  a London run are comparable.
* **Ten radio stations are generated, not downloaded** — each city has a groove
  (kick/clap/hat pattern), scale and lead voice; the station is synthesised live
  from those numbers. Zero audio assets, so the game stays one file.
* **Language packs.** English and Nigerian Pidgin ship; `STR` in `03-i18n.js` is
  the whole surface — add `fr`, `sw`, `pt`, `ar` by copying one object.
* **Local leaderboards per city, global board, and your own runs** — all offline.
* **One seam from local to worldwide.** Set `BOARD_API` in `04-core.js`:

  ```js
  const BOARD_API = 'https://your-worker.workers.dev';
  ```

  then implement two endpoints:

  ```
  GET  /board?city=lagos   -> [{ "name": "Ada", "idx": 12345 }]
  POST /score              <- { name, city, route, idx, stars }
  ```

  A Cloudflare Worker + D1 (or Express + SQLite) is ~40 lines. The game keeps
  working offline and falls back to the local board when the fetch fails, so
  shipping this can never break play.

What it would need before a real global launch (deliberately out of scope here):

* Server-side score validation (the client currently trusts itself — fine for
  friends, not for prizes).
* Accounts or at least a signed device id, so a board can't be spammed.
* Localised number/date formatting per locale, RTL layout for Arabic, and fonts
  that cover Devanagari/Thai/Arabic script for place names.
* App-store packaging (the PWA installs from the browser today; Capacitor or
  Bubblewrap would wrap the same file for Play/App Store).

---

## Balance (measured, not guessed)

`qa/test.js` drives an autopilot and a horn-mashing "expert" over all 30 routes
and writes `qa/sim.json`. Current numbers after tuning:

* 60/60 routes complete without errors.
* Every route earns at least 1 star; median run lands on 2 of 3.
* ~43% of routes reach 3 stars with ordinary play, ~63% with aggressive
  combo play — so three stars feels earned but not brutal.
* Parts cost 6k → 600k credits and are star-gated at 0 / 5 / 16 / 38 / 66 stars,
  which paces upgrades against the city unlock order (Accra at 3★, New York at 60★).

Also verified: 0 console errors, ~30 fps at a 4× CPU throttle with software
rendering (real GPUs are far faster) with an adaptive quality governor that drops
effects and raster resolution before it drops frames, and full offline boot after
the service worker caches the game.

---

## Why it looks like this

The reference points were `danfo.horpey.dev` (an arcade Lagos driving game) and
`lagoslife.eliysites.com` (a Lagos life-sim). This takes the arcade core that
makes those fun to pick up — one thumb, instant feedback, a reason to send a
screenshot to a friend — and puts a progression spine under it: stars, a fleet,
upgrades, cities, seasons. Nigeria first, because the detail is the fun (you know
what LASTMA is, you know why the horn matters), but the engine is deliberately
dumb about geography so the same love can be pointed at Accra, Nairobi or Jakarta
with a data pack, not a rewrite.
